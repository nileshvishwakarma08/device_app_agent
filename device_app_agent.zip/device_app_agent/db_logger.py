def log_task(episode, task, action, reward):
    with open("task_logs.txt", "a") as f:
        f.write(f"Episode {episode}: Task = {task} | Action = {action} | Reward = {reward}\n")

