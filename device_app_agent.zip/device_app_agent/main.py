print("Starting agent simulation...")

from agent import QAgent
from environment import TaskEnv
from db_logger import log_task
import random

if __name__ == "__main__":
    env = TaskEnv()
    qagent = QAgent(actions=env.tasks)

    episodes = 200
    epsilon = 1.0        
    epsilon_decay = 0.995
    epsilon_min = 0.1

    for episode in range(1, episodes + 1):
        task = env.get_task()  
        if random.uniform(0, 1) < epsilon:
            action = random.choice(env.tasks)  
        else:
            action = qagent.choose_action(task)  

        reward = env.perform_action(action)  
        qagent.learn(task, action, reward)
        log_task(episode, task, action, reward)
        print(f"Episode {episode}: Task = {task} | Action = {action} | Reward = {reward}")

        if epsilon > epsilon_min:
            epsilon *= epsilon_decay

    print("Training complete.")

    print("\nLearned Q-table:")
    for key, val in qagent.q_table.items():
        print(f"{key}: {val:.2f}")

