import random

class QAgent:
    def __init__(self, actions, alpha=0.1, gamma=0.9):
        self.q_table = {}  # {(state, action): Q-value}
        self.actions = actions
        self.alpha = alpha
        self.gamma = gamma

    def choose_action(self, state):
        q_values = {action: self.q_table.get((state, action), 0) for action in self.actions}
        max_q = max(q_values.values())
        best_actions = [action for action, q in q_values.items() if q == max_q]
        return random.choice(best_actions)

    def learn(self, state, action, reward):
        old_q = self.q_table.get((state, action), 0)
        future_q = max([self.q_table.get((state, a), 0) for a in self.actions])
        new_q = old_q + self.alpha * (reward + self.gamma * future_q - old_q)
        self.q_table[(state, action)] = new_q

