
import random

class TaskEnv:
    def __init__(self):
        self.tasks = [
            "open file",
            "open template",
            "check notification",
            "play music",
            "mute",
            "unmute"
        ]
        self.current_task = None

        # Define correct actions
        self.correct_actions = {
            "open file": "open file",
            "open template": "open template",
            "check notification": "check notification",
            "play music": "play music",
            "mute": "mute",
            "unmute": "unmute"
        }

        # Define follow-up action mapping
        self.follow_up_actions = {
            "check notification": "open template", 
            "open file": "open template",        
            
       }
    def get_task(self):
        self.current_task = random.choice(self.tasks)
        return self.current_task

    def perform_action(self, action):
        if action == self.correct_actions.get(self.current_task):
            return 2  # +2 for correct task completion
        elif self.follow_up_actions.get(self.current_task) == action:
            return 1  # +1 for follow-up suggestion
        elif action in self.correct_actions.values():
            return -1  # -1 for irrelevant but known action
        else:
            return 0  # 0 for idle or unknown command
           
            
       
